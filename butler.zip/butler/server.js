var express=require('express');
var nodemailer = require("nodemailer");
var app=express();
var path = require('path')
var mysql = require('mysql');


var con = mysql.createConnection({
     host: "localhost",
     user: "root",
     password: "root",
     database: "mybutler11"
});

/*
	Here we are configuring our SMTP Server details.
	STMP is mail server which is responsible for sending and recieving email.
*/

var smtpTransport = nodemailer.createTransport({
    service: 'gmail',
    host: 'smtp.gmail.com',
    port: 587,
    auth: {
        user: 'mybutler0@gmail.com',
        pass: 'butler@123'
    },
    tls: {rejectUnauthorized: false},
    debug:true
});


/*------------------SMTP Over-----------------------------*/

/*------------------Routing Started ------------------------*/

app.get('/',function(req,res){
	res.sendFile(path.resolve('index.html'));
});
111
app.get('/send',function(req,res){
	var user={
		username : req.query.username,
		email : req.query.email,
		password : req.query.password
	}
	console.log(user);
	
	//Database code
	    con.connect(function(err) {
  if (err) throw  err;
  console.log("connected");
  var sql = "CREATE TABLE signup11 (username VARCHAR(255), email VARCHAR(255), password VARCHAR(255))";
  var sql = "INSERT INTO `signup11`(`username`,`email`, `password`) VALUES ('"+req.query.username+"','"+req.query.email+"','"+req.query.password+"')";
  con.query(sql, function(err, result)  {
   if(err) throw err;
   console.log("table created");
  });
});
	
	//end
	
	//Subscribe mail
	var mailOptions={
		to : req.query.email,
		subject : req.query.subject,
		text : req.query.text
	}
	console.log(mailOptions);
	smtpTransport.sendMail(mailOptions, function(error, response){
   	 if(error){
        	console.log(error);
		res.end("error");
	 }else{
        	console.log("Message sent: " + response.message);
		res.end("sent");
    	 }
});
	//end
	
	
	
});

	//end
	app.get('/send/signin',function(req,res){
	var signin={
		user : req.query.user,
		pass : req.query.pass
	}
	console.log(signin);
	//Database code
	    con.connect(function(err) {
  if (err) throw  err;
  console.log("connected");
  var uuu = req.query.user;
 con.query("SELECT password FROM signup11 WHERE username = ?",[uuu], function (err, result) {
    if (err) throw err;
    console.log(result);
          sql = result;
  });

  if(req.query.pass == sql){
	console.log("login success");
  }else{
	console.log("login failed");
  }  
  con.query(sql, function(err, result)  {
   if(err) throw err;
   console.log("table created");
  });
});
	
	//end
	
});


app.get('/send/index',function(req,res){
	var mailOptions={
		to : req.query.to,
		subject : req.query.subject,
		text : req.query.text
	}
	console.log(mailOptions);
	smtpTransport.sendMail(mailOptions, function(error, response){
   	 if(error){
        	console.log(error);
		res.end("error");
	 }else{
        	console.log("Message sent: " + response.message);
		res.end("done");
    	 }
});
});
/*--------------------Routing Over----------------------------*/

app.use(express.static("./"));
app.listen(3000,function(){
	console.log("Express Started on Port 3000");
});
